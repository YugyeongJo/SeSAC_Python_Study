class InvalidTokenException(Exception):
    pass 

class NotClosedParenthesesException(Exception):
    pass 